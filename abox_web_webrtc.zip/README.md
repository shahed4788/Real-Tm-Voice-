# ABox WebRTC Voice Changer — Demo Project

This project is a demo scaffold that mimics an ABox-style UI and provides:
- Web UI (index.html) with dark theme and voice presets
- Simple granular pitch shifter (JS) for live microphone preview
- WebRTC call demo that sends processed audio to peers
- Simple Node.js WebSocket signaling server (`/server/signaling.js`)

## How to use

1. Replace `assets/logo.svg` with your logo (48x48 recommended).
2. Update `app.js` constant `SIGNALING_SERVER` with your server URL (e.g. `ws://your-ip:8888`).
3. Start signaling server:
   ```
   cd server
   npm install
   node signaling.js
   ```
4. Serve the `index.html` (e.g. `npx http-server .` or deploy to Netlify/Vercel).
5. Open the page on two devices or two browser tabs.
   - Click **Preview Microphone** and allow microphone permission.
   - Click **Start Call** on one side to send an offer; the other side will receive the offer via the signaling server.
   - Processed voice will be sent to the remote peer.

## Notes & Limitations
- The pitch shifter here is a **basic, educational implementation** and not production-grade.
- Browser compatibility: best on modern Chrome/Chromium-based browsers.
- This web demo **cannot change voice inside other apps (WhatsApp, Telegram, Messenger)** due to OS-level audio routing restrictions.
- For an Android app wrapper, you can embed this site in a WebView or build a PWA.

## Files
- `index.html`, `style.css`, `app.js`
- `assets/logo.svg`, `assets/girl1.svg` ... `girl6.svg`
- `server/signaling.js`, `server/package.json`

Replace assets and branding as you like.

