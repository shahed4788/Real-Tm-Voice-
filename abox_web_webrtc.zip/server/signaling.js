/*
Simple broadcast WebSocket signaling server.
Usage:
  npm install
  node signaling.js
This server echoes messages to other connected clients.
*/
const WebSocket = require('ws');
const port = process.env.PORT || 8888;
const wss = new WebSocket.Server({ port: port });
console.log('Signaling server running on port', port);
wss.on('connection', function connection(ws) {
  console.log('client connected');
  ws.on('message', function incoming(message) {
    // broadcast to all other clients
    wss.clients.forEach(function each(client) {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  });
  ws.on('close', ()=>console.log('client disconnected'));
});
