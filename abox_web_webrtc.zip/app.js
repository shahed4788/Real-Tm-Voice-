/*
ABox-style WebRTC + WebAudio demo.
- Simple granular pitch shifter (basic)
- WebRTC with WebSocket signaling (broadcast style)
- Replace SIGNALING_SERVER with your server address (ws:// or wss://)
*/

const SIGNALING_SERVER = 'ws://YOUR_SERVER_IP:8888'; // <- replace before deploy

let localStream = null;
let processedStream = null;
let pc = null;
let ws = null;
let localAudioNode = null;
let audioContext = null;
let shifter = null;

const presets = [
  {name:'Original', pitch:1.0},
  {name:'AI Female5', pitch:1.25},
  {name:'AI Girl2', pitch:1.35},
  {name:'AI Male2', pitch:0.85},
  {name:'Deep Boy', pitch:0.75},
  {name:'Robot', pitch:1.0, robot:true}
];

function el(id){return document.getElementById(id)}

function setStatus(s){ el('status').innerText = 'Status: '+s }

function makeUI(){
  const pbox = el('presets');
  presets.forEach((p, i)=>{
    const div = document.createElement('div'); div.className='preset';
    div.innerHTML = `<div style="font-weight:600">${p.name}</div><div style="font-size:12px;color:#bdbbd3">pitch:${p.pitch}</div>`;
    const btn = document.createElement('button'); btn.innerText='Apply';
    btn.onclick = ()=>{ selectPreset(i); };
    div.appendChild(btn); pbox.appendChild(div);
  });

  const avatars = el('avatars');
  for(let i=1;i<=6;i++){
    const a = document.createElement('div'); a.className='avatar';
    a.innerHTML = `<img src="assets/girl${i}.svg" alt="g${i}" /><div style="margin-top:6px">Girl ${i}</div>`;
    avatars.appendChild(a);
  }
}

function selectPreset(i){
  const p = presets[i];
  if(!audioContext) return;
  if(shifter) shifter.setPitch(p.pitch || 1.0, p.robot||false);
  setStatus('Preset: '+p.name);
}

/* Basic granular pitch shifter using ScriptProcessorNode (not production-grade) */
class GranularPitchShifter {
  constructor(context, pitch=1.0){
    this.ctx = context;
    this.pitch = pitch;
    this.robot = false;
    this.input = context.createGain();
    this.output = context.createGain();
    this.bufferSize = 1024;
    this.script = context.createScriptProcessor(this.bufferSize, 1, 1);
    this.script.onaudioprocess = this._onAudio.bind(this);
    this.input.connect(this.script);
    this.script.connect(this.output);
    this.grainWindow = this._hannWindow(this.bufferSize);
    this.readPos = 0;
    this.buffer = new Float32Array(this.bufferSize*8);
    this.writePos = 0;
  }
  _hannWindow(N){
    const w = new Float32Array(N);
    for(let i=0;i<N;i++) w[i]=0.5*(1-Math.cos(2*Math.PI*i/(N-1)));
    return w;
  }
  setPitch(p, robot=false){
    this.pitch = p; this.robot = robot;
  }
  _onAudio(ev){
    const input = ev.inputBuffer.getChannelData(0);
    const output = ev.outputBuffer.getChannelData(0);
    // write into ring buffer
    for(let i=0;i<input.length;i++){
      this.buffer[this.writePos] = input[i];
      this.writePos = (this.writePos+1)%this.buffer.length;
    }
    // simple resampling read
    let rp = this.readPos;
    const inc = 1.0 / this.pitch; // if pitch>1, inc<1 (faster read -> higher pitch)
    for(let i=0;i<output.length;i++){
      // linear interpolate
      const i0 = Math.floor(rp) % this.buffer.length;
      const i1 = (i0+1)%this.buffer.length;
      const frac = rp - Math.floor(rp);
      let v = (1-frac)*this.buffer[i0] + frac*this.buffer[i1];
      if(this.robot){ // bitcrusher-ish robot effect
        v = Math.sign(v)*Math.pow(Math.abs(v),0.9);
        if(Math.random()<0.02) v*=0.9;
      }
      output[i]=v;
      rp += inc;
      if(rp>=this.buffer.length) rp-=this.buffer.length;
    }
    this.readPos = rp;
  }
  connect(dest){ this.output.connect(dest) }
  disconnect(){ this.output.disconnect() }
}

/* Start local preview (microphone -> processed -> speakers) */
async function startLocalPreview(){
  if(!navigator.mediaDevices) { alert('getUserMedia not supported'); return; }
  audioContext = new (window.AudioContext || window.webkitAudioContext)();
  localStream = await navigator.mediaDevices.getUserMedia({audio:true});
  const src = audioContext.createMediaStreamSource(localStream);
  shifter = new GranularPitchShifter(audioContext,1.0);
  src.connect(shifter.input);
  shifter.connect(audioContext.destination);
  // processedStream via MediaStreamDestination
  const dest = audioContext.createMediaStreamDestination();
  shifter.connect(dest);
  processedStream = dest.stream;
  setStatus('Local preview running');
}

/* WebRTC functions (simple P2P with signaling server broadcast) */
function connectSignaling(url){
  ws = new WebSocket(url);
  ws.onopen = ()=>{ setStatus('Signaling connected'); };
  ws.onmessage = (evt)=>{ handleSignal(evt.data); };
  ws.onclose = ()=>{ setStatus('Signaling closed'); };
}
async function startCall(){
  if(!processedStream){ setStatus('Start local preview first'); return; }
  connectSignaling(SIGNALING_SERVER);
  pc = new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
  // add processed audio track
  processedStream.getTracks().forEach(t=>pc.addTrack(t, processedStream));
  pc.ontrack = (ev)=>{ const ra = el('remoteAudio'); ra.srcObject = ev.streams[0]; setStatus('Remote stream received'); };
  pc.onicecandidate = (e)=>{ if(e.candidate){ ws.send(JSON.stringify({type:'candidate',candidate:e.candidate})); } };
  // create offer
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  ws.send(JSON.stringify({type:'offer',sdp:offer.sdp}));
  setStatus('Call offer sent — waiting answer');
}
async function handleSignal(msg){
  try{
    const obj = JSON.parse(msg);
    if(obj.type==='offer' && !pc){
      // incoming offer (act as callee)
      pc = new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
      // add our processed track if available
      if(processedStream) processedStream.getTracks().forEach(t=>pc.addTrack(t, processedStream));
      pc.ontrack = (ev)=>{ el('remoteAudio').srcObject = ev.streams[0]; setStatus('In call'); };
      pc.onicecandidate = (e)=>{ if(e.candidate) ws.send(JSON.stringify({type:'candidate',candidate:e.candidate})); };
      await pc.setRemoteDescription({type:'offer',sdp:obj.sdp});
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      ws.send(JSON.stringify({type:'answer',sdp:answer.sdp}));
    } else if(obj.type==='answer' && pc){
      await pc.setRemoteDescription({type:'answer',sdp:obj.sdp});
      setStatus('Call established');
    } else if(obj.type==='candidate' && pc){
      try{ await pc.addIceCandidate(obj.candidate); }catch(e){console.warn(e);}
    }
  }catch(e){ console.error(e) }
}

function hangup(){
  if(pc){ pc.close(); pc=null; }
  if(ws){ ws.close(); ws=null; }
  setStatus('Idle');
}

/* Wire UI */
window.addEventListener('load', ()=>{
  makeUI();
  el('startLocal').addEventListener('click', ()=>{ startLocalPreview().catch(e=>alert(e)); });
  el('startCall').addEventListener('click', ()=> startCall().catch(e=>alert(e)));
  el('hangup').addEventListener('click', ()=> hangup());
  setStatus('Ready');
});
